# NodeMCU-FlightController-MPU6050
A simple Flight Controller based on ESP8266/NodeMCU &amp; MPU6050

Full Video Link: https://youtu.be/OMMk6xxYXTc

Channel Link: www.youtube.com/c/DIYLIFEHACKER
